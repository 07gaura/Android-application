package com.example.covidtracker;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.PieModel;

public class Details extends AppCompatActivity {
    PieChart pieChart;

    private int positionCountry;
    TextView cases, tcases, deaths, tdeaths, recover, trecover, active, test, critical, cname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        Intent intent = getIntent();
        positionCountry = intent.getIntExtra("position", 0);

        getSupportActionBar().setTitle("Total Cases");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);

        cname = findViewById(R.id.countryName);
        cname.setText(country.countryModelsList.get(positionCountry).getCountry());

        cases = findViewById(R.id.textViewd1);
        tcases = findViewById(R.id.textViewd2);
        deaths = findViewById(R.id.textViewd3);
        tdeaths = findViewById(R.id.textViewd4);
        recover = findViewById(R.id.textViewd5);
        trecover = findViewById(R.id.textViewd6);
        active = findViewById(R.id.textViewd7);
        test = findViewById(R.id.textViewd8);
        critical = findViewById(R.id.textViewd9);
        pieChart = findViewById(R.id.piechart1);

        cases.setText(country.countryModelsList.get(positionCountry).getCases());
        tcases.setText(country.countryModelsList.get(positionCountry).getTodayCases());
        deaths.setText(country.countryModelsList.get(positionCountry).getDeaths());
        tdeaths.setText(country.countryModelsList.get(positionCountry).getTodayDeaths());
        recover.setText(country.countryModelsList.get(positionCountry).getRecovered());
        trecover.setText(country.countryModelsList.get(positionCountry).getTodayRecovered());
        active.setText(country.countryModelsList.get(positionCountry).getActive());
        test.setText(country.countryModelsList.get(positionCountry).getTests());
        critical.setText(country.countryModelsList.get(positionCountry).getCritical());

        pieChart.addPieSlice(new PieModel("cases", Integer.parseInt(tcases.getText().toString()), Color.parseColor("#FFD300")));
        pieChart.addPieSlice(new PieModel("recovered", Integer.parseInt(recover.getText().toString()), Color.parseColor("#50C878")));
        pieChart.addPieSlice(new PieModel("deaths", Integer.parseInt(deaths.getText().toString()), Color.parseColor("#f42802")));
        pieChart.addPieSlice(new PieModel("active", Integer.parseInt(active.getText().toString()), Color.parseColor("#398ad7")));
        pieChart.startAnimation();
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}