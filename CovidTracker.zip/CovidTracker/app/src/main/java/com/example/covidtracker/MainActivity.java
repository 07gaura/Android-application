package com.example.covidtracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.leo.simplearcloader.SimpleArcLoader;

import org.eazegraph.lib.charts.PieChart;
import org.eazegraph.lib.models.PieModel;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    TextView tcases2, tcases3, tcases4, tcases5, tcases6, tcases7, tcases8, tcases9;
    Button btn;
    SimpleArcLoader simpleArcLoader;
    ScrollView scrollView;
    PieChart pieChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tcases2 = findViewById(R.id.textView2);
        tcases3 = findViewById(R.id.textView3);
        tcases4 = findViewById(R.id.textView4);
        tcases5 = findViewById(R.id.textView5);
        tcases6 = findViewById(R.id.textView6);
        tcases7 = findViewById(R.id.textView7);
        tcases8 = findViewById(R.id.textView8);
        tcases9 = findViewById(R.id.textView9);
        btn = (Button)findViewById(R.id.button);
        simpleArcLoader = findViewById(R.id.loader);
        scrollView = findViewById(R.id.scrollstats);
        pieChart = findViewById(R.id.piechart);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, country.class);
                startActivity(intent);
            }
        });

        fetchData();
    }

    private void fetchData() {

        String URL = "https://corona.lmao.ninja/v2/all/";

        simpleArcLoader.start();

        StringRequest request = new StringRequest(Request.Method.GET, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response.toString());

                    tcases2.setText(jsonObject.getString("cases"));
                    tcases3.setText(jsonObject.getString("recovered"));
                    tcases4.setText(jsonObject.getString("critical"));
                    tcases5.setText(jsonObject.getString("active"));
                    tcases6.setText(jsonObject.getString("todayCases"));
                    tcases7.setText(jsonObject.getString("deaths"));
                    tcases8.setText(jsonObject.getString("todayDeaths"));
                    tcases9.setText(jsonObject.getString("affectedCountries"));

                    pieChart.addPieSlice(new PieModel("cases", Integer.parseInt(tcases2.getText().toString()), Color.parseColor("#FFD300")));
                    pieChart.addPieSlice(new PieModel("recovered", Integer.parseInt(tcases3.getText().toString()), Color.parseColor("#50C878")));
                    pieChart.addPieSlice(new PieModel("deaths", Integer.parseInt(tcases7.getText().toString()), Color.parseColor("#f42802")));
                    pieChart.addPieSlice(new PieModel("active", Integer.parseInt(tcases5.getText().toString()), Color.parseColor("#398ad7")));
                    pieChart.startAnimation();
                    simpleArcLoader.stop();
                    simpleArcLoader.setVisibility(View.GONE);
                    scrollView.setVisibility(View.VISIBLE);
                }catch (JSONException e){
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                simpleArcLoader.stop();
                simpleArcLoader.setVisibility(View.GONE);
                scrollView.setVisibility(View.VISIBLE);
                Toast.makeText(MainActivity.this, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
}